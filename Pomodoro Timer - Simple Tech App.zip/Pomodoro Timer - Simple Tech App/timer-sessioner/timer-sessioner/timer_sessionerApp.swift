//
//  timer_sessionerApp.swift
//  timer-sessioner
//
//  Created by Timur Lisitskiy on 24.02.2024.
//

import SwiftUI

@main
struct timer_sessionerApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            //ContentView()
                //.environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
