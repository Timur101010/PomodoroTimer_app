import SwiftUI // Importing the SwiftUI library for building the user interface
import UserNotifications // Importing the library for working with notifications
import Combine // Importing the library for working with asynchronous programming

struct ContentView: View { // Definition of the ContentView structure, which is a view
    @State private var workDuration: Int = 25 // State to store the duration of work
    @State private var breakDuration: Int = 5 // State to store the duration of break
    @State private var timerMode: TimerMode = .initial // State to store the timer mode
    @State private var timeRemaining: Int = 0 // State to track the remaining time
    @State private var timer: Timer? // State to store the timer object
    @State private var cancellable: AnyCancellable? // State to store the subscription
    @State private var isSessionCompleted: Bool = false // State to track session completion

    enum TimerMode { // Enumeration TimerMode, which defines timer states
        case initial // Initial state of the timer
        case running // State of the running timer
        case paused // State of the paused timer
    }

    var body: some View { // Definition of the view body
        VStack { // Vertical VStack container to arrange elements in a column
            Text("Pomodoro Timer").font(.title) // Heading "Pomodoro Timer"
            Spacer() // Spacing between elements
            HStack { // Horizontal HStack container to arrange elements in a row
                Text("Work duration: \(workDuration) min") // Text with the work duration
                Button(action: { // Button to increase the work duration
                    if self.workDuration < 60 { // Checking the maximum value
                        self.workDuration += 1 // Increasing the work duration by 1 minute
                    }
                }) {
                    Image(systemName: "plus.circle") // Plus icon
                        .font(.title) // Setting the font size
                }
                Button(action: { // Button to decrease the work duration
                    if self.workDuration > 1 { // Checking the minimum value
                        self.workDuration -= 1 // Decreasing the work duration by 1 minute
                    }
                }) {
                    Image(systemName: "minus.circle") // Minus icon
                        .font(.title) // Setting the font size
                }
            }
            HStack { // Horizontal HStack container to arrange elements in a row
                Text("Break duration: \(breakDuration) min") // Text with the break duration
                Button(action: { // Button to increase the break duration
                    if self.breakDuration < 15 { // Checking the maximum value
                        self.breakDuration += 1 // Increasing the break duration by 1 minute
                    }
                }) {
                    Image(systemName: "plus.circle") // Plus icon
                        .font(.title) // Setting the font size
                }
                Button(action: { // Button to decrease the break duration
                    if self.breakDuration > 1 { // Checking the minimum value
                        self.breakDuration -= 1 // Decreasing the break duration by 1 minute
                    }
                }) {
                    Image(systemName: "minus.circle") // Minus icon
                        .font(.title) // Setting the font size
                }
            }
            Spacer() // Spacing between elements
            ZStack { // ZStack container to layer elements
                Circle() // Circular shape
                    .stroke(Color.blue, lineWidth: 10) // Circle outline with blue color and 10 line width
                    .frame(width: 200, height: 200) // Setting the circle size
                    .padding() // Adding padding
                    .opacity(isSessionCompleted ? 0.5 : 1.0) // Setting opacity based on session state
                    .animation(Animation.easeInOut(duration: 1.0).repeatForever().delay(0.5)) // Blinking animation
                Text("\(timeRemaining.minutesAndSeconds())") // Text with the remaining time
                    .font(.title) // Setting the font size
            }
            Spacer() // Spacing between elements
            HStack(spacing: 20) { // Horizontal HStack container to arrange buttons in a row with a specified spacing
                Button(action: { // Button to start the timer
                    startTimer() // Calling the method to start the timer
                }) {
                    Text("Start") // Text for the "Start" button
                        .fontWeight(.bold) // Setting the font weight to bold
                        .padding() // Adding padding
                        .background(Color.green) // Setting the button background color to green
                        .foregroundColor(.white) // Setting the text color to white
                        .cornerRadius(10) // Setting the corner radius
                }
                Button(action: { // Button to stop the timer
                    stopTimer() // Calling the method to stop the timer
                }) {
                    Text("Stop") // Text for the "Stop" button
                        .fontWeight(.bold) // Setting the font weight to bold
                        .padding() // Adding padding
                        .background(Color.red) // Setting the button background color to red
                        .foregroundColor(.white) // Setting the text color to white
                        .cornerRadius(10) // Setting the corner radius
                }
                Button(action: { // Button to reset the timer
                    resetTimer() // Calling the method to reset the timer
                }) {
                    Text("Reset") // Text for the "Reset" button
                        .fontWeight(.bold) // Setting the font weight to bold
                        .padding() // Adding padding
                        .background(Color.gray) // Setting the button background color to gray
                        .foregroundColor(.white) // Setting the text color to white
                        .cornerRadius(10) // Setting the corner radius
                }
            }
            Spacer() // Spacing between elements
        }.padding() // Adding padding to the entire VStack
        .onAppear { // Called when the view appears on the screen
            cancellable = Timer.publish(every: 1, on: .main, in: .common) // Creating a Timer data source
                .autoconnect() // Automatically connecting
                .sink(receiveValue: { _ in // Handling values from the source
                    if self.timerMode == .running { // Checking the timer mode
                        if self.timeRemaining > 0 { // Checking the remaining time
                            self.timeRemaining -= 1 // Decreasing the remaining time by 1 second
                        } else { // If time is up
                            self.timerMode = (self.timerMode == .running) ? .paused : .initial // Changing the timer mode
                            sendNotification() // Calling the method to send a notification
                        }
                    }
                })
        }
    }

    func startTimer() { // Method to start the timer
        timeRemaining = workDuration * 60 // Setting the remaining time according to the work duration
        timerMode = .running // Setting the timer mode to "running"
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in // Creating a timer
            if self.timeRemaining > 0 { // Checking the remaining time
                self.timeRemaining -= 1 // Decreasing the remaining time by 1 second
            } else { // If time is up
                self.timerMode = .initial // Setting the timer mode to "initial"
                self.timeRemaining = self.breakDuration * 60 // Setting the remaining time according to the break duration
                sendNotification() // Calling the method to send a notification
                self.isSessionCompleted.toggle() // Changing the session completion state
            }
        }
    }

    func stopTimer() { // Method to stop the timer
        timerMode = .paused // Setting the timer mode to "paused"
        timer?.invalidate() // Stopping the timer
    }

    func resetTimer() { // Method to reset the timer
        timerMode = .initial // Setting the timer mode to "initial"
        timer?.invalidate() // Stopping the timer
        timeRemaining = 0 // Resetting the remaining time
    }

    func sendNotification() { // Method to send a notification
        let content = UNMutableNotificationContent() // Creating notification content
        content.sound = .default // Setting the default sound
        
        if timerMode == .initial { // Checking the timer mode
            content.title = "Time to Work!" // Setting the notification title
            content.body = "Start your work session now." // Setting the notification text
        } else {
            content.title = "Take a Break!" // Setting the notification title
            content.body = "It's time to relax and take a break." // Setting the notification text
        }

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false) // Creating a trigger for the notification
        let request = UNNotificationRequest(identifier: "timerNotification", content: content, trigger: trigger) // Creating a request to send the notification
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil) // Adding the request to the notification center
    }
}

extension Int { // Extension of the Int type
    func minutesAndSeconds() -> String { // Method to represent time in "minutes:seconds" format
        let minutes = self / 60 // Calculating minutes
        let seconds = self % 60 // Calculating seconds
        return String(format: "%02d:%02d", minutes, seconds) // Formatting the time
    }
}

struct ContentView_Previews: PreviewProvider { // Structure for previewing
    static var previews: some View { // Definition of the preview
        ContentView() // Returning the ContentView view
    }
}
